My Website Hub — Android app project

অ্যাপের সুবিধা:
- নিজের ওয়েবসাইটের নাম ও URL যোগ করা
- সেভ করা ওয়েবসাইট তালিকা থেকে খুলতে পারা
- ওয়েবসাইট মুছে ফেলা
- অ্যাপ বন্ধ করলেও তালিকা ফোনে সেভ থাকে
- প্রথমবার আপনার দেওয়া Netlify ওয়েবসাইটটি যোগ করা আছে

APK বানানোর নিয়ম:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio থেকে এই ZIP ফাইলটি Extract করে MyWebsiteHub ফোল্ডার Open করুন।
3. Gradle sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. APK তৈরি হলে Android Studio-তে 'locate' চাপুন; APK ফোনে কপি করে ইনস্টল করুন।

নোট: এই ZIP-এ Android Studio project source আছে, সরাসরি ইনস্টলযোগ্য APK নয়।
প্রথমবার ইনস্টল করার সময় Android ফোনে APK ইনস্টল করার অনুমতি দিতে হতে পারে।
