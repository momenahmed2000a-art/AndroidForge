package com.example.mywebsitehub

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var address: EditText
    private lateinit var web: WebView
    private lateinit var sitesBox: LinearLayout
    private val prefs by lazy { getSharedPreferences("hub", MODE_PRIVATE) }
    private val sites = mutableListOf<Pair<String, String>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(23, 21, 43)
        window.navigationBarColor = Color.rgb(23, 21, 43)
        loadSites()
        buildUi()
        if (sites.isNotEmpty()) openSite(sites[0].second)
    }

    private fun loadSites() {
        val saved = prefs.getString("sites", null)
        if (saved == null) {
            sites.add("আমার ওয়েবসাইট" to "https://spiffy-travesseiro-df4989.netlify.app/")
            saveSites()
        } else {
            saved.split("\n").filter { it.contains("|") }.forEach {
                val p = it.split("|", limit = 2)
                if (p.size == 2) sites.add(p[0] to p[1])
            }
        }
    }

    private fun saveSites() {
        prefs.edit().putString("sites", sites.joinToString("\n") { "${it.first}|${it.second}" }).apply()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(247, 246, 252))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(14))
            setBackgroundColor(Color.rgb(23, 21, 43))
        }
        header.addView(TextView(this).apply {
            text = "My Website Hub"
            textSize = 23f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        header.addView(TextView(this).apply {
            text = "আপনার সব ওয়েবসাইট, এক অ্যাপে"
            textSize = 14f
            setTextColor(Color.rgb(218, 214, 240))
            setPadding(0, dp(4), 0, dp(12))
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        address = EditText(this).apply {
            hint = "https://example.com"
            textSize = 14f
            singleLine = true
            setPadding(dp(12), 0, dp(8), 0)
            setBackgroundColor(Color.WHITE)
        }
        row.addView(address, LinearLayout.LayoutParams(0, dp(48), 1f))
        row.addView(Button(this).apply {
            text = "যান"
            setOnClickListener {
                val url = normalize(address.text.toString())
                if (url != null) openSite(url) else toast("সঠিক ওয়েবসাইটের লিংক দিন")
            }
        }, LinearLayout.LayoutParams(dp(70), dp(48)))
        header.addView(row)
        root.addView(header)

        val siteHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(10), dp(4))
        }
        siteHeader.addView(TextView(this).apply {
            text = "আমার ওয়েবসাইটসমূহ"
            textSize = 17f
            setTextColor(Color.rgb(35, 32, 55))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        siteHeader.addView(Button(this).apply {
            text = "+ যোগ করুন"
            setOnClickListener { showAddDialog() }
        })
        root.addView(siteHeader)

        val scroll = ScrollView(this)
        sitesBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(12), dp(8))
        }
        scroll.addView(sitesBox)
        root.addView(scroll, LinearLayout.LayoutParams(-1, dp(150)))
        refreshSites()

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.javaScriptCanOpenWindowsAutomatically = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
        }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun refreshSites() {
        sitesBox.removeAllViews()
        sites.forEachIndexed { index, item ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(5), dp(5), dp(5))
                setBackgroundColor(Color.WHITE)
            }
            val label = TextView(this).apply {
                text = "${item.first}\n${item.second}"
                textSize = 13f
                setTextColor(Color.rgb(35, 32, 55))
                setPadding(dp(4), dp(5), dp(4), dp(5))
                maxLines = 2
                setOnClickListener { openSite(item.second) }
            }
            card.addView(label, LinearLayout.LayoutParams(0, dp(54), 1f))
            card.addView(Button(this).apply {
                text = "খুলুন"
                setOnClickListener { openSite(item.second) }
            })
            card.addView(Button(this).apply {
                text = "×"
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setMessage("এই ওয়েবসাইটটি মুছে ফেলবেন?")
                        .setNegativeButton("না", null)
                        .setPositiveButton("মুছুন") { _, _ ->
                            sites.removeAt(index); saveSites(); refreshSites()
                        }.show()
                }
            })
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = dp(7)
            sitesBox.addView(card, lp)
        }
    }

    private fun showAddDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val name = EditText(this).apply { hint = "ওয়েবসাইটের নাম" }
        val url = EditText(this).apply {
            hint = "https://example.com"
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        box.addView(name)
        box.addView(url)
        AlertDialog.Builder(this)
            .setTitle("নতুন ওয়েবসাইট যোগ করুন")
            .setView(box)
            .setNegativeButton("বাতিল", null)
            .setPositiveButton("যোগ করুন") { _, _ ->
                val normalized = normalize(url.text.toString())
                if (normalized == null) {
                    toast("সঠিক ওয়েবসাইটের লিংক দিন")
                } else {
                    val title = name.text.toString().trim().ifEmpty { normalized }
                    sites.add(title to normalized)
                    saveSites()
                    refreshSites()
                    openSite(normalized)
                }
            }.show()
    }

    private fun normalize(raw: String): String? {
        var s = raw.trim()
        if (s.isEmpty()) return null
        if (!s.startsWith("https://", true) && !s.startsWith("http://", true)) s = "https://$s"
        val uri = android.net.Uri.parse(s)
        return if (uri.host?.contains(".") == true && uri.scheme in listOf("https", "http")) s else null
    }

    private fun openSite(url: String) {
        address.setText(url)
        web.loadUrl(url)
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
